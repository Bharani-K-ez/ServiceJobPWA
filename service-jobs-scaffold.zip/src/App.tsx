import { useState } from 'react'
import './App.css'
import { login, logout } from './api/auth'
import { getAuthToken } from './api/authToken'

/**
 * Minimal working example wiring the login form to the API client, so you
 * can confirm the tenant code + auth token flow works end-to-end against
 * the real API before building real screens on top of it. Replace freely.
 */
function App() {
  const [companyCode, setCompanyCode] = useState('')
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [status, setStatus] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault()
    setBusy(true)
    setStatus(null)
    try {
      const result = await login({ username, password, companyCode })
      setStatus(result.message)
      if (result.success) {
        const token = await getAuthToken()
        console.log('Stored auth token:', token)
      }
    } catch (err) {
      setStatus(err instanceof Error ? err.message : 'Request failed')
    } finally {
      setBusy(false)
    }
  }

  return (
    <main className="app">
      <h1>ServiceJobs</h1>
      <form onSubmit={handleSubmit} className="login-form">
        <label>
          Company code
          <input
            value={companyCode}
            onChange={(e) => setCompanyCode(e.target.value)}
            placeholder="e.g. ezTest"
            required
          />
        </label>
        <label>
          Username
          <input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </label>
        <label>
          Password
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </label>
        <button type="submit" disabled={busy}>
          {busy ? 'Signing in…' : 'Sign in'}
        </button>
      </form>
      {status && <p className="status">{status}</p>}
      <button type="button" onClick={() => void logout()}>
        Clear stored session
      </button>
    </main>
  )
}

export default App
