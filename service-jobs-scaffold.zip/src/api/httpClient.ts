import axios from 'axios'
import type { InternalAxiosRequestConfig } from 'axios'
import { API_BASE_URL } from '../config/env'
import { getAuthToken, clearAuthToken } from './authToken'
import { getTenantCode } from './tenant'

export const httpClient = axios.create({
  baseURL: API_BASE_URL,
})

// Every request needs `?code=<tenantCode>` - the backend's tenant
// middleware reads it before anything else runs, including auth.
// Attaching it here means no call site has to remember to pass it.
httpClient.interceptors.request.use(async (config: InternalAxiosRequestConfig) => {
  const tenantCode = await getTenantCode()
  if (tenantCode) {
    config.params = { ...config.params, code: tenantCode }
  }

  const token = await getAuthToken()
  if (token) {
    config.headers.set('Authorization', `Bearer ${token}`)
  }

  return config
})

// A 401 means the stored token is gone/expired - drop it so the app's
// auth-state check reliably falls back to "logged out" on the next read,
// rather than repeatedly sending a dead token.
httpClient.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (axios.isAxiosError(error) && error.response?.status === 401) {
      await clearAuthToken()
    }
    return Promise.reject(error)
  },
)
